#!/usr/bin/env ruby
require 'faker'
puts "hello #{Faker::Name.name}"