fail "ERROR: 'rake/rdoctask' is obsolete and no longer supported. " +
  "Use 'rdoc/task' (available in RDoc 2.4.2+) instead."
